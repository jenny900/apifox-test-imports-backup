const http = require("http");
const fs = require("fs");

// 创建本地服务器来从其接收数据
const server = http.createServer();

const port = 5566;

// 监听请求事件
server.on("request", (request, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  const data = fs.readFileSync("./ant_gateway-frontapi.yaml");

  res.end(data.toString("utf8"));
});

server.listen(port, () => {
  console.log(`Server listening on port: ${port}`);
});
